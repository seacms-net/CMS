<?php

define('EmpireBak_VERSION','5.1');

define('EmpireBak_LASTTIME','201607281030');

define('EmpireBak_UPDATE','1');

 ?>