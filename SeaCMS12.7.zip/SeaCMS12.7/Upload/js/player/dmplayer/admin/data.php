<?php
 $yzm =  array (
  'danmuon' => 'on',
  'ads' => 
  array (
    'set' => 
    array (
      'group' => '1',
      'state' => '1',
      'pic' => 
      array (
        'time' => '20',
        'img' => '',
        'link' => '',
      ),
      'vod' => 
      array (
        'url' => '',
        'link' => '',
      ),
    ),
    'pause' => 
    array (
      'pic' => '',
      'link' => '',
    ),
  ),
  'color' => '#00a1d6',
  'logo' => '',
  'trytime' => '999999999999',
  'waittime' => '5',
  'sendtime' => '5',
  'dmrule' => '../dmku/dm_rule.html',
  'pbgjz' => '草,操,妈,逼,滚,网址,网站,支付宝,企,关注,wx,微信,qq,QQ',
  'jzuser' => '',
);
?>