<?php 
header('Content-Type:text/html;charset=utf-8');
ob_start();
set_time_limit(0);
error_reporting(0);
require_once(dirname(__FILE__)."/config.php");
CheckPurview();
require_once('../data/common.inc.php'); 
$mysqli = new mysqli($cfg_dbhost,$cfg_dbuser,$cfg_dbpwd,$cfg_dbname,$cfg_dbport);
if ($mysqli->connect_error) {die("数据库连接失败" . $mysqli->connect_error);}

/***********
$tables = $mysqli->query("SHOW TABLES");
 while ($table = $tables->fetch_array()) {
    $tableName = $table[0]; 
    // 获取每个表的所有列
    $columns = $mysqli->query("SHOW FULL COLUMNS FROM `$tableName`");    
    while ($column = $columns->fetch_assoc()) {
        $columnName = $column['Field'];
        $type = $column['Type'];
        // 只处理字符串类型的列
        if (preg_match('/^(enum|set|varchar|text|char|mediumtext|longtext|tinytext)/i', $type)) {           
            $allxxxxx[]=$tableName.'#'.$columnName;
        }
    }
} 
print_r($allxxxxx); die;
**********************/
$Tarray=array(sea_admin999name,sea_admin999password,sea_admin999loginip,sea_arcrank999membername,sea_arcrank999purviews,sea_cck999ckey,sea_cck999uname,sea_co_cls999clsname,sea_co_config999cname,sea_co_data999tname,sea_co_data999v_name,sea_co_data999v_pic,sea_co_data999v_spic,sea_co_data999v_gpic,sea_co_data999v_director,sea_co_data999v_enname,sea_co_data999v_lang,sea_co_data999v_actor,sea_co_data999v_publishyear,sea_co_data999v_publisharea,sea_co_data999v_note,sea_co_data999v_tags,sea_co_data999v_from,sea_co_data999v_inbase,sea_co_data999v_des,sea_co_data999v_playdata,sea_co_data999v_downdata,sea_co_data999v_jq,sea_co_data999v_longtxt,sea_co_filters999Name,sea_co_filters999sFind,sea_co_filters999sStart,sea_co_filters999sEnd,sea_co_filters999sReplace,sea_co_news999n_title,sea_co_news999n_keyword,sea_co_news999n_pic,sea_co_news999n_author,sea_co_news999n_content,sea_co_news999n_outline,sea_co_news999tname,sea_co_news999n_from,sea_co_news999n_inbase,sea_co_news999n_entitle,sea_co_type999tname,sea_co_type999siteurl,sea_co_type999playfrom,sea_co_type999autocls,sea_co_type999coding,sea_co_type999sock,sea_co_type999listconfig,sea_co_type999itemconfig,sea_co_url999url,sea_co_url999pic,sea_co_url999succ,sea_comment999username,sea_comment999ip,sea_comment999msg,sea_comment999pic,sea_content999body,sea_count999userip,sea_count999serverurl,sea_count999updatetime,sea_crons999type,sea_crons999name,sea_crons999filename,sea_crons999minute,sea_danmaku_ip999ip,sea_danmaku_list999id,sea_danmaku_list999type,sea_danmaku_list999text,sea_danmaku_list999color,sea_danmaku_list999size,sea_danmaku_list999ip,sea_danmaku_list999user,sea_danmaku_report999id,sea_danmaku_report999text,sea_danmaku_report999type,sea_danmaku_report999ip,sea_data999v_name,sea_data999v_pic,sea_data999v_spic,sea_data999v_gpic,sea_data999v_vip,sea_data999v_actor,sea_data999v_publisharea,sea_data999v_note,sea_data999v_tags,sea_data999v_director,sea_data999v_enname,sea_data999v_lang,sea_data999v_extratype,sea_data999v_jq,sea_data999v_nickname,sea_data999v_reweek,sea_data999v_tvs,sea_data999v_company,sea_data999v_ver,sea_data999v_psd,sea_data999v_longtxt,sea_erradd999author,sea_erradd999ip,sea_erradd999errtxt,sea_flink999url,sea_flink999webname,sea_flink999msg,sea_flink999email,sea_flink999logo,sea_guestbook999title,sea_guestbook999uname,sea_guestbook999ip,sea_guestbook999msg,sea_hyzbuy999uname,sea_ie999ip,sea_jqtype999tname,sea_member999username,sea_member999nickname,sea_member999password,sea_member999email,sea_member999regip,sea_member999vipendtime,sea_member999acode,sea_member999repswcode,sea_member999msgbody,sea_member999pic,sea_member_group999gname,sea_member_group999gtype,sea_member_group999g_auth,sea_myad999adname,sea_myad999adenname,sea_myad999intro,sea_myad999adsbody,sea_mytag999tagname,sea_mytag999tagdes,sea_mytag999tagcontent,sea_news999n_title,sea_news999n_pic,sea_news999n_spic,sea_news999n_gpic,sea_news999n_author,sea_news999n_entitle,sea_news999n_outline,sea_news999n_keyword,sea_news999n_from,sea_news999n_content,sea_playdata999body,sea_playdata999body1,sea_search_keywords999keyword,sea_search_keywords999spwords,sea_tags999tag,sea_tags999vids,sea_temp999v_name,sea_temp999v_pic,sea_temp999v_actor,sea_temp999v_publishyear,sea_temp999v_publisharea,sea_temp999v_note,sea_temp999v_playdata,sea_temp999v_des,sea_temp999v_director,sea_temp999v_enname,sea_temp999v_lang,sea_topic999name,sea_topic999enname,sea_topic999template,sea_topic999pic,sea_topic999spic,sea_topic999gpic,sea_topic999des,sea_topic999vod,sea_topic999news,sea_topic999keyword,sea_topic999content,sea_type999tname,sea_type999tenname,sea_type999templist,sea_type999templist_1,sea_type999templist_2,sea_type999title,sea_type999keyword,sea_type999description,sea_type999unionid,sea_zyk999zname,sea_zyk999zapi,sea_zyk999zinfo)
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> </title>
<link  href="img/style.css" rel="stylesheet" type="text/css" />
<link  href="img/style.css" rel="stylesheet" type="text/css" />
<script src="js/common.js" type="text/javascript"></script>
<script src="js/main.js" type="text/javascript"></script>
</head>
<body>
<script type="text/JavaScript">if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='后台首页&nbsp;&raquo;&nbsp;工具&nbsp;&raquo;&nbsp;挂马清除工具 ';</script>
<div class="r_main">
  <div class="r_content">
    <div class="r_content_1">
<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tb_style">
<tbody><tr class="thead">
<td colspan="5" class="td_title">挂马清除工具</td>
</tr>
</tbody></table>	
</div>

<div style="margin: 20px 20px 20px 20px;
    padding: 5px;
    font-size: 14px;
    line-height: 26px;
    background-color: #e6f2fb;
    border-radius: 2px;
    width: 800px;">
使用本工具前<font style="color:#FF0000">务必备份</font>网站数据库
<br>本工具理论上可以清除全站任意数据中的恶意跳转代码，类似 &lt;script... &nbsp; &lt;iframe...
<br>超低配服务器，可修改后台/admin_safe_xss.php第82行 $pagesize=1000 减少每次执行数
<br>根据数据库大小不同，本操作可能需要较长时间，请耐心等待
</div>
<script>
function loading() {
document.getElementById('loaddiv1').style.visibility = 'hidden';
location.href='admin_safe_xss.php?action=delXSS&tt=<?php echo $Tarray[0];?>&page=1&tkey=0';
}
</script>
<?php 
if($action==""){
?>
<div id="loaddiv1">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" class="btn" value="一键清除网站数据库挂马" onclick="loading();" >
</div>

<?php 
}
if($action=="delXSS"){

$pagesize=1000; //每页处理的数据条数


//$page 页数
$page2=$page+1;
$TTT=explode('999',$tt);
$tableName = $TTT[0]; //数据表
$columnName = $TTT[1]; //字段名称
$start= ($page-1)*$pagesize;
//$tkey 字段数据数组键值序号key
$tkey2=$tkey+1;
$Cnum = $start + $pagesize; //当前页数据行号
$COLcount=count($Tarray);   //总字段数

$countR=$mysqli->query("SELECT COUNT(*) AS total FROM $tableName"); 
if($countR === FALSE) {die("查询数据总条数失败: " . $conn->error);}
$count = $countR->fetch_array();
$count = $count['total']; 
$pagecount=ceil(intval($count)/$pagesize); //总页数echo $count.'='.$pagecount;

echo '<font style="color:#00AA00;font-size:14px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;正在清理&nbsp;【'.$tableName.'】-【'.$columnName.'】&nbsp;&nbsp;页数'.$page.'/'.$pagecount.'&nbsp;&nbsp;行数'.$start.'-'.$Cnum.'/'.$count.'&nbsp;&nbsp;字段'.$tkey2,'/'.$COLcount.'</font><br>';

$sqlA = "SELECT $columnName FROM $tableName limit $start,$pagesize";                                 //echo $sqlA.'<br>';
$result = $mysqli->query($sqlA);                                                                                       //print_r($result);die;
while($row = $result->fetch_assoc()) {                                                                                 //echo $row[$columnName] .'<br>';	
	if($row[$columnName] !=''){
		$cleanData = preg_replace('/on\w+=".*?"/i', '', $row[$columnName]);
		$cleanData = preg_replace('/<script.*?>.*?<\/script.*?>/is', '', $cleanData);
		$cleanData = preg_replace('/<script.*?\>/is', '', $cleanData);
		$cleanData = preg_replace('/<script.*?\.js"/is', '', $cleanData);
		$cleanData = preg_replace('/<script.*?\.js/is', '', $cleanData);
		$cleanData = preg_replace('/<iframe.*?>.*?<\/iframe.*?>/is', '', $cleanData);
		$cleanData = preg_replace('/<iframe.*?\>/is', '', $cleanData);
		$cleanData = preg_replace('/<iframe.*?\.js"/is', '', $cleanData);
		$cleanData = preg_replace('/<iframe.*?\.js/is', '', $cleanData);	            //echo $cleanData.'<br>';	
		$sqlB="UPDATE $tableName SET $columnName = '$cleanData' WHERE $columnName = '$row[$columnName]'";                          //echo $sqlB."\n\r<br>";
		$mysqli->query($sqlB);
		}
}




// 生成下次执行的url
$nextpage='';
if($page < $pagecount){$nextpage='admin_safe_xss.php?action=delXSS&tt='.$tt.'&page='.$page2.'&tkey='.$tkey;}
else{$nextpage='admin_safe_xss.php?action=delXSS&tt='.$Tarray[$tkey2].'&page=1&tkey='.$tkey2;}

//跳转到下一页 or 任务结束 跳出
if($tkey2 < $COLcount){
	echo "<script language=\"javascript\">setTimeout(\"Next();\",1000);function Next(){location.href='".$nextpage."';}</script>";
	}
else{
	echo '<font style="color:#00AA00;font-size:14px;"><strong><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;处理完成</strong></font>';
	}

}
?>



<br><br>
</div>
</div>
<?php 
viewFoot();
?>
</body>
</html>